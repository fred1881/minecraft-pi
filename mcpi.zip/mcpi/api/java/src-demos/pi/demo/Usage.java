package pi.demo;

/**
 *
 * @author Daniel Frisk, twitter:danfrisk
 */
class Usage {
    public static void main(String[] args) {
        System.out.println("Read the file HOW_TO_RUN.txt in the McPiDemos directory");
    }
}
